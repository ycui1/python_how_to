**We can use the taskier app to manage our daily tasks.**

## License
MIT License